﻿namespace KolkoKrzyz
{
    public enum MarkType
    {

        Free,
        Nought,
        Cross
    }
}